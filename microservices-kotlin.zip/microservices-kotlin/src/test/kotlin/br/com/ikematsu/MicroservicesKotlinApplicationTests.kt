package br.com.ikematsu

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MicroservicesKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
